
<?php

require '../api/include/sessions.php';

$session = new Session();

if(!$session->check_session()){
  header("location: ../login");
}

if($session->isAdmin()){
  header("location: ../admin/");
}

?>

 <!DOCTYPE html>
<html>
<head>
  <title>Course Camp</title>
  <link href="../img/Logo.png" rel="icon" sizes="16x25" type="image/png" />
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/yazz.styles.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script defer src="https://kit.fontawesome.com/a81368914c.js"></script>
<!--   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
  <script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <style type="text/css">
    .table-td{

      padding: 5px;
      border-bottom: .05em solid rgba(211, 211, 211, .5)

    }

    .user-td{
      padding: 10px;
    }

    .overlay-wrap{

      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 9999 !important;
      background-color: rgba(0, 0, 0, .175);
      padding: 6px;
      padding-top: 20%;

    }

    .main-wrap{

      background-color: #fff;
      border-radius: 8px;
      padding: 10px;

    }
  </style>

</head>
<body style="background-color: #fff;">
	<div class="container" style="background-color: #fff;">

    <div class="nav navbar navbar-fixed-top" style="background-color: #fff;height: 50px;border-bottom:.05em solid rgba(211, 211, 211, .5);">
      
      <div class="media container" style="padding-top: 10px">
        <div class="media-left" style="padding-top:px;">

          <table style="">
          <tr>
            <td class="user-td">
              <center>

                <a href="../">
                <span class="glyphicon glyphicon-arrow-left"></span>
                </a>
              </center>
            </td>
            <td class="user-td">

                <center>
                 <div class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown">
                    <span class="glyphicon glyphicon-cog"></span>
                  </a>
                  <ul class="dropdown-menu list-group">
                    
                    <li class="list-group-item">
                      <a class="update-open">
                        Update Account
                      </a>
                    </li>
                    <!-- <li class="list-group-item">
                      <a class="update-open">
                        Update Subjects
                      </a>
                    </li> -->
                    <li class="list-group-item">
                      <a class="logout-btn app-bolder-text" style="">
                        Logout
                      </a>
                    </li>
                    <li class="list-group-item">
                      <a class="delete-btn">
                        Delete Account
                      </a>
                    </li>
                  </ul>
                </div>
                </center>
              
            </td>
          </tr>
        </table>
          
          

        </div>
        <div class="media-body">

          <span class="app-max-text name"></span>
          <span class="app-grey-text surname" style="display: block;line-height: 1"></span>
          
        </div>
        <div class="media-right">
          <center>
            <a class="view-subjects btn btn-success">
              View Your Subjects
            </a>
            <a class="view-qualified btn btn-success" style="display: none;">
              View Qualified Courses
            </a>
          </center>
        </div>
      </div>

    </div>

    <div class="user-subjects" style="display: none;">
      
      <div class="space-large"></div>
      <div class="space-large"></div>
      <table class="table table-bordered table-subjects">
        <thead>
          <center>
            <h3>Your Subjects</h3>
          </center>
        </thead>
        <tr>
          <td>Subject</td>
          <td>Subject Level</td>
        </tr>
      </table>

    </div>

    <div class="user-courses">
      <div class="space-large"></div>
      <div class="space-large"></div>
      <table class="table table-bordered table-courses">
        <thead>
          <center>
            <h3>Courses You Qualify For</h3>
          </center>
        </thead>
        <tr>
          <td>Faculty</td>
          <td>Course</td>
          <td>APS</td>
          <td>Campus</td>
          <td>Apply</td>
        </tr>
        
      </table>

    </div>

    <!-- UPDATE USER INFO -->

    <div class="overlay-wrap" style="display: none;">
      
      <div class="row">
        
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
          
          <div class="main-wrap">
        
            <div class="media">
              <div class="media-body">
                <span class="app-max-text">Update</span>
              </div>
              <div class="media-right">
                <button class="btn btn-success update-close">close</button>
              </div>
            </div>

          
          <div class="space-medium"></div>
          <center>
            <span class="app-grey-text" id="update-error"></span>
          </center>
          <form class="form-group update-form">
            
            <div class="input-group input-group-lg">
              
              <label>Name :</label>
              <input type="text" name="name" placeholder="Name"  class="form-control update-name" />

            </div>

            <div class="space-medium"></div>

            <div class="input-group input-group-lg">
              
              <label>Email :</label>
              <input type="email" name="email" placeholder="Email" class="form-control update-email" />
            </div>

            <div class="space-medium"></div>

            <div class="input-group input-group-lg">
              
              <label>Identity Number</label>
              <input type="text" name="id" placeholder="Identity Number" class="form-control update-id" />
              <span class="id-validator"></span>
            </div>

            <div class="space-medium"></div>

            <input type="hidden" name="context" value="5">

            <button class="btn btn-success" class="update-btn form-control" >UPDATE</button>

          </form>
          </div>
        </div>
        <div class="col-lg-3"></div>

      </div>

    </div>

    <div class="app-toast">
      <span class="toast-text"></span>
    </div>

    <div class="nav navbar navbar-fixed-bottom" style="height: 50px;padding-left: 15px;padding-right: 20px;border-top:.05em solid rgba(211, 211, 211, .5);padding-top: 10px;background-color: #fff;">

      <div class="media">
        <div class="media-left">
          
          <center>
            <span class="results-loader"></span>
          </center>

        </div>
        <div class="media-body">

            <span class="app-max-text">Your APS</span>
          
        </div>
        <div class="media-right">
          <center>
            <span class="user-aps app-max-text"></span>
          </center>
        </div>
      </div>
    </div>

  </div>
  <script type="text/javascript" src="../js/main.js"></script>
  <script type="text/javascript">

    const user = <?php echo json_encode($session->user()); ?>;
    (function(http, $, USER){

      $.html('.name', USER.name)
      $.html('.surname', USER.surname)

      $.value('.update-name', USER.name)
      $.value('.update-email', USER.email)
      $.value('.update-id', USER.id)

      let updateOpen = false

      let toggleUpdate = function(){

        if(updateOpen){

          $.get('.overlay-wrap').style.display = 'none'

          updateOpen = false

        }else{

          $.get('.overlay-wrap').style.display = 'block'
          updateOpen = true

        }

      }

      $.get('.update-open').onclick = function(){

        toggleUpdate()

      }

      $.get('.update-close').onclick = function(){

        toggleUpdate()

      }

      let checkInputs = function(self){

        let inputs = self.elements

          for(let i = 0; i <= 3; i++){
            console.log(inputs.item(i).value)
            if(inputs.item(i).value === ''){
              el.html("#update-error", 'No Field Should Be Empty')
              return true
            }

          }

          false

      }

      ontype(el.get('.update-id'))

      $.get('.update-form').onsubmit = function(e){

        e.preventDefault()

        $.get('#update-error').append($.loader())

        if(checkInputs(this)) return

        let payload = validIdentityNumber(el.get('.update-id').value, '.id-validator')

          if(!payload.valid) return

        http.request({
          method : 'POST',
          url : '../api/user/',
          form : new FormData($.get('.update-form'))
        }, data => {

          $.html('#update-error', data.message)

          $.toast(data.message)

        })

      }

      let APS = 0

      let calculateAPS = function(aps){

        if(aps.length > 0){

          aps.forEach(mark => {

            APS += parseInt(mark, 10)

          })

          $.html('.user-aps', APS)

        }

      }

      let form = new FormData()
      form.append('context', 1)

      $.get('.results-loader').append($.loader())

      http.request({
        method : 'POST',
        url    : '../api/user/',
        form : form
      }, data => {

        $.html('.results-loader', '')

        let table = $.get('.table-courses')

        if(data.error){

          if(data.user){

            /*calculateAPS(data.user.user_aps.split(','))*/

            $.html('.user-aps', APS)
            /*userSubjects(data.user)*/
          }

          userSubjects(data.user)

          let tr = $.create('tr', 'table-tr')
          let ErrorRow = $.create('td', 'table-td')

          table.append(tr)
          tr.append(ErrorRow)
          ErrorRow.setAttribute('colspan', 4)
          ErrorRow.innerHTML = `<center><h3><samp>${data.message}</samp></h3></center>`

        }else{

          $.html('.user-aps', APS)
          
          userSubjects(data.user)

          data.courses.forEach(course => {

            let tr = $.create('tr', 'table-tr')
            let Faculty = $.create('td', 'table-td')
            let Course = $.create('td', 'table-td')
            let CourseAPS = $.create('td', 'table-td')
            let Campus = $.create('td', 'table-td')
            let Apply = $.create('td', 'table-td')
            let URL = $.create('a', 'link')
            
            table.append(tr)
            tr.append(Faculty, Course, CourseAPS, Campus, Apply)

            Faculty.innerHTML = course.faculty
            Course.innerHTML = course.course
            CourseAPS.innerHTML = course.course_aps
            Campus.innerHTML = course.campus

            Apply.append(URL)

            URL.href = 'https://www.tut.ac.za'/*"https://ienabler.tut.ac.za/pls/prodi41/gen.gw1pkg.gw1view"*/
            URL.innerHTML = 'Apply@TUT'

          })

        }

      })
      let shown = true
      let toggleSubjects = function() {

        if(shown){

          $.get('.view-qualified').style.display = 'block'
          $.get('.view-subjects').style.display = 'none'

          

          $.get('.user-subjects').style.display = 'block'
          $.get('.user-courses').style.display = 'none'

          shown = false

        }else{

          $.get('.view-qualified').style.display = 'none'
          $.get('.view-subjects').style.display = 'block'

          

          $.get('.user-subjects').style.display = 'none'
          $.get('.user-courses').style.display = 'block'

          shown = true
        }

      }

      $.get('.view-qualified').onclick = () => {toggleSubjects()}

      $.get('.view-subjects').onclick = () => {toggleSubjects()}

      let userSubjects = function(user){

        let table = $.get('.table-subjects')

        if(!user){

          let tr = $.create('tr', 'table-tr')
          let ErrorRow = $.create('td', 'table-td')

          table.append(tr)
          tr.append(ErrorRow)
          ErrorRow.setAttribute('colspan', 2)
          ErrorRow.innerHTML = `<center><h3><samp>You Have Not Choosen Any Subjects Yet!</samp></h3></center>`

          

          return
        }

        let subjects = user.user_subject.split(',')
        let aps = user.user_aps.split(',')

        if(subjects.length > 0){

          subjects.forEach((subject, i) => {
            console.log(subject)
            let tr = $.create('tr', 'table-tr')
            let Subject = $.create('td', 'table-td')
            let SubjectLevel = $.create('td', 'table-td')

            Subject.innerHTML = subject
            SubjectLevel.innerHTML = aps[i]

            table.append(tr)
            tr.append(Subject, SubjectLevel)

          })

          calculateAPS(user.user_aps.split(','))

        }else{

          let tr = $.create('tr', 'table-tr')
          let ErrorRow = $.create('td', 'table-td')

          table.append(tr)
          tr.append(ErrorRow)
          ErrorRow.setAttribute('colspan', 2)
          ErrorRow.innerHTML = `<center><h3><samp>You Have Not Choosen Any Subjects Yet!</samp></h3></center>`

        }

      }

      $.get('.logout-btn').onclick = () => {

          let form = new FormData()

          form.append('context', 3)
          form.append('logout', true)

          $.get('.results-loader').append($.loader())

          http.request({
            method : 'POST',
            url : '../api/user/',
            form : form
          }, data => {

            $.html('.results-loader', '')

            $.toast(data.message)

            window.location = '../login'

          })

        }

      $.get('.delete-btn').onclick = function(){

        let form = new FormData()
        form.append("context", 4)

        $.get('.results-loader').append($.loader())

        http.request({
          method : 'POST',
          url : '../api/user/',
          form : form
        }, data => {

          $.html('.results-loader', '')

          if(data.error){
            $.toast(data.message)
          }else{
            window.location = ''
          }

        })

      }

    })(http, el, user)

  </script>
</body>
</html>
