<?php

require '../api/include/sessions.php';

$session = new Session();

if($session->check_session()){
  header("location: ../");
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Course Camp</title>
  <link href="../img/Logo.png" rel="icon" sizes="16x25" type="image/png" />
	<link rel="stylesheet" type="text/css" href="../css/style.css">
  <link rel="stylesheet" type="text/css" href="../css/load.css">
  <link rel="stylesheet" type="text/css" href="../css/yazz.styles.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.4/pdfobject.min.js" integrity="sha512-mW7siBAOOJTkMl77cTke1Krn+Wz8DJrjMzlKaorrGeGecq0DPUq28KgMrX060xQQOGjcl7MSSep+/1FOprNltw==" crossorigin="anonymous"></script>
  <script type="text/javascript" src="../js/main.js"></script>
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">

  <script>
         $(document).ready(function(){
             $("select").change(function(){
                 $(this).find("option:selected").each(function(){
                     var optionValue = $(this).attr("value");
                     if(optionValue){
                         $(".box").not("." + optionValue).hide();
                         $("." + optionValue).show();
                     } else{
                         $(".box").hide();
                     }
                 });
             }).change();
         });
      </script>
      <script>
         function Reg() {
                  var login = document.getElementById("login-content");
                  var reg = document.getElementById("reg-content");

                 login.style.display = "none";
                 reg.style.display = "flex";

             }
             function Login() {
                      var login = document.getElementById("login-content");
                      var reg = document.getElementById("reg-content");

                     login.style.display = "flex";
                     reg.style.display = "none";

                 }
  </script>
</head>
<body>
      <div id="webLoader" class="webLoader">
         <center><img src="../img/loader.gif" alt="Loading..." /></center>
      </div>
	<div class="container">

        <div id="login-content" class="login-content box">
    			<form id="login-user">
    				<img src="../img/Logo.png">
    				 <center>
           <samp style="color:red" id="login-error"></samp>    
             </center>
               		<div class="input-div one">
               		   <div class="i">
               		   		<i class="fas fa-user"></i>
               		   </div>
               		   <div class="div">
               		   		<!-- <h5>Email</h5> -->
               		   		<input type="email" name="email" class="input" placeholder="Email Address" require>
               		   </div>
               		</div>
               		<div class="input-div one">
               		   <div class="i">
               		    	<i class="fas fa-lock"></i>
               		   </div>
               		   <div class="div">
               		    	<!-- <h5>Password</h5> -->
               		    	<input type="password" name="password" class="input" placeholder="Password" require>
                        <input type="hidden" name="context" value="1">
                	   </div>
                	</div>
                	<a href="../forgot/">Forgot Password?</a>
                	<input type="submit" name="login" class="btn" value="signin">
                <p style="font-size: 0.9rem;"> Don't have an account?<a onclick="Reg()">SignUp</a></p>
                </form>
            </div>

            <div id="reg-content" class="reg-content box">
        			<form id="register-user">
        				<img src="../img/Logo.png">
        				<h4 class="title">Register</h4>
                <center>
                  <samp id="register-error" style="color:red"></samp>
                </center>
                <div class="input-div one">
                   <div class="i">
                      <i class="fas fa-user"></i>
                   </div>
                   <div class="div">
                      <!-- <h5>Name</h5> -->
                      <input type="text" name="name" class="input" placeholder="Name" require>
                   </div>
                </div>
                <div class="input-div one">
                   <div class="i">
                      <i class="fas fa-user"></i>
                   </div>
                   <div class="div">
                      <!-- <h5>Surname</h5> -->
                      <input type="text" name="surname" class="input" placeholder="Surname" require>
                   </div>
                </div>
                <div class="input-div one">
                   <div class="i">
                      <i class="fas fa-calendar-alt"></i>
                   </div>
                   <div class="div">
                      <!-- <h5>ID Number</h5> -->
                      <input type="number" name="id_number" class="input id-number" placeholder="ID Number" require>
                      
                   </div>

                </div>
                <samp class="id-validator"></samp>
                <div class="input-div one">
                   		   <div class="i">
                   		   		<i class="fas fa-envelope"></i>
                   		   </div>
                   		   <div class="div">
                   		   		<!-- <h5>Email</h5> -->
                   		   		<input type="email" name="email" class="input" placeholder="Email Address" require>
                   		   </div>
                   		</div>
                   		<div class="input-div pass">
                   		   <div class="i">
                   		    	<i class="fas fa-lock"></i>
                   		   </div>
                   		   <div class="div">
                   		    	<!-- <h5>Password</h5> -->
                   		    	<input type="password" name="password" class="input" placeholder="Password" require>
                    	   </div>
                    	</div>
                    	<input type="submit" name="signup" class="btn" value="Signup">
                    <p> You Already have an account?<a onclick="Login()">SignIn</a></p>
                    </form>
                </div>
                <div class="app-toast">
                  <span class="toast-text"></span>
                </div>

    </div>
    
    <script>
        (function(){
          var loaderDiv = document.getElementById("webLoader"),

            show = function(){
              loaderDiv.style.display = "flex";
              setTimeout(hide, 3000); // 5 seconds
            },

            hide = function(){
              loaderDiv.style.display = "none";
            };

          show();

        })();

        let checkInputs = function(self){

          let inputs = self.elements

            for(let i = 0; i < inputs.length; i++){

              if(inputs.item(i).value === ''){
                el.html("#login-error", 'You Have To Fill In All Your Login Credentials')
                return true
              }

            }

            false

        }


         el.get('#login-user').onsubmit = function(e){

            e.preventDefault()
            el.html("#login-error", '')

            if(checkInputs(this)) return

            el.get('#login-error').append(el.loader())

            http.request({
              method : 'POST',
              url    : '../api/auth/',
              form   : new FormData(el.get('#login-user'))
            }, function(data){

               if(data.error){

                 el.html("#login-error", data.message)
                 el.toast(data.message)
               }else{

                el.toast(data.message)

                  window.location = '../'

               }

            });

          }

          ontype(el.get('.id-number'))


          el.get('#register-user').onsubmit = function(e){

            e.preventDefault()
            el.html("#register-error", '')

            let payload = validIdentityNumber(el.get('.id-number').value, '.id-validator')

            if(!payload.valid) return

            if(checkInputs(this)) return

              el.get('#register-error').append(el.loader())

            http.request({
              method : 'POST',
              url    : '../api/auth/create/',
              form   : new FormData(el.get('#register-user'))
            }, function(data){

              if(data.error){

                el.html('#register-error', data.message)
                el.toast(data.message)

              }else{

                let form = new FormData()
                form.append('email', data.email)
                form.append('password', data.password)
                form.append('context', 1)

                http.request({
                  method : 'POST',
                  url : '../api/auth/',
                  form : form
                }, function(data){

                  if(data.error){

                      el.html("#register-error", data.message)

                   }else{

                      el.toast(data.message)
                      window.location = '../'

                   }

                })


              }

            });

          }

     </script>

</body>
</html>
