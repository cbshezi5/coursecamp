<?php
   class Connection{
       private $_AT_LOCALHOST_USER='root';
       private $_USER_PASSWORD='';
       private $_DATABASE='course_campDB';
       private $_AT_ADDRESS='localhost';
       public function __CONX(){
        $_CONXX=new mysqli($this->_AT_ADDRESS,$this->_AT_LOCALHOST_USER,$this->_USER_PASSWORD,$this->_DATABASE);
          if($_CONXX){
           return $_CONXX;
          }else{
            die("Unable To Connect");
          }
       }
   };

  $connx = new Connection;

   //$connx = new Connection;
   //$cnx = $connx->__CONX(); mysqli_query($connx->__CONX(),"")

  ?>